
#include <iostream> //geral para "cin", "cout"
#include <conio.h> // para switch
#include <string.h> // para tabelas etc
#include <iomanip> // para manipuladores como o setw

using namespace std;

void fonctionSomme();
void fonctionSoustration();
void fonctionMultiplication();
void fonctionDivision();

int main()
{
    /*Como eu resolvi fazer em uma funnçao soh, resolvi colocar as variaveis como locais que fica mais bonito, como locais 
    fica na cor azul claro dentro das operaçoes etc.*/

    const int E0 = 0, E1 = 1, E2 = 2, E3 = 3, E4 = 4, E5 = 5; //opcoes do menu
    int etat = E0; //nome da funcao do switch e inicializaçao das mesmas
    char choix, choix2; // declarando a escolha do  switch
    int option = 1;
    float n1 = 0.0, n2 = 0.0; // numeros escolhidos pelo usuario
    float somme = 0.0, soustration = 0.0, division = 0.0, multiplication = 0.0; // soma, substraçao, divisao e multiplicaçao
    int reponse = 0; //Declarando as respostas do usuario e inicializando-as
    int nombre; //tableau de multiplication
    int i, j; // les conteurs pour la table de multiplication
    

    do // O 'do' foi colocado aqui para que o menu fique funcionando a nao ser que a pessoa clique no QUIT, que é a opçao 4
    {
        switch (etat) //Aqui eu inicio as opçoes do menu, chamadas de 'etat' que sao do primeiro menu
        {
        case E0: //A opçao zero é o menu em si
            cout << "\n-------------------------------------------";
            cout << "\n        Mini Calculatrice";
            cout << "\n-------------------------------------------";
            cout << "\n        MENU LOGICIEL";
            cout << "\n-------------------------------------------";
            cout << "\n 1 - Nouvelle opération";
            cout << "\n 2 - Définir les paramètres";
            cout << "\n 3 - Aide";
            cout << "\n Q - Quitter le logiciel";
            cout << "\n CHOIX= ";
            choix = _getch();

            switch (choix) { //Essa parte aqui serve para dar funcionalidade ao menu e escolher as opçoes
            case '1':
                etat = E1; break;
            case '2':
                etat = E2; break;
            case '3':
                etat = E3; break;
            case 'Q':
                etat = E4; break; //O E4 é soh para fechar o programa, nao tem uma opçao verdadeira para o E5
            }
            break;

        case E1: //Ao clicar na opçao 1, entra nas informaçoes abaixo:

            cout<< "\n-------------------------------------------";
            cout<< "\n             Mini Calculatrice";
            cout<< "\n-------------------------------------------";
            cout<< "\n       NOUVELLE OPÉRATION – OPTION" << " " << option;
            cout<< "\n-------------------------------------------";

            if(option == 1)
            {
                // se opçao for 1, chamar  1 - Additionneuse à 1 seule opération, etc.

                cout<< "\n Cette option permet de faire 1 opération de 2 nombre entiers";
                cout<< "\n-------------------------------------------------------";
                cout<< "\n Quell'est la operation que vous vouler faire? (1 = somme, 2 = soustration, 3 = multiplication, 4 = division)";
                cin >> reponse;

                if (reponse == 1)
                {
                  fonctionSomme();
                }
                else if (reponse == 2)
                {
                  fonctionSoustration(); 
                }
                else if (reponse == 3)
                {
                  fonctionMultiplication();
                }
                else if (reponse == 4)
                {
                  fonctionDivision(); 
                }

                cout << "\n Cliquez sur n'importe quelle touche pour revenir au menu principal.";
            }
            else if(option == 2)
            {
                cout<< "\n-------------------------------------------";
                cout<< "\n            Mini Calculatrice";
                cout<< "\n-------------------------------------------";
                cout<< "\n     Table de Multiplication – OPTION" << " " << option;
                cout<< "\n-------------------------------------------";
                cout<< "\n Cette option permet d’afficher la table de multiplication à la demande";
                cout << "Donnez moi le nombre que tu veux multiplier de 1 - 10: ";
                cin >> nombre;
                cout<< "\n-------------------------------------------";
                cout<< "\n Table de Multiplication de 1 – " << nombre;
                cout<< "\n-------------------------------------------" << endl;

                //Création de la table de multiplication

                

                for (i = 1; i <= nombre * 5; i++)
                {
                    cout << "-"; //correto, primeira linha
                }

                cout << "\n" << "| X |"; //esse é o X entre linha e coluna zero

                for (i = 1; i <= nombre; i++)
                {
                    cout << setw(2) << i << setw(2) << "|"; //correto, primeira linha
                }

                cout << "\n";

                for (i = 1; i <= nombre; i++)
                {
                    cout << "|" << setw(2) << i << setw(2) << "|"; //correto, é o indice da primeira coluna

                    for (j = 1; j <= nombre; j++)
                    {
                        cout << setw(2) << i * j << setw(2) << "|";
                    }
                    cout << "\n";
                }

                for (i = 1; i <= nombre * 5; i++)
                {
                    cout << "-"; //correto, primeira linha
                }

                cout << "\n";
                cout << "\n Cliquez sur n'importe quelle touche pour revenir au menu principal.";
            }
            else if(option == 3)
            {
                cout<< "\n-------------------------------------------";
                cout<< "\n            Mini Calculatrice";
                cout<< "\n-------------------------------------------";
                cout<< "\n   Calculatrice Scientifique – OPTION" << " " << option;
                cout<< "\n-------------------------------------------";
                cout<< "\n Bien vouloir attendre la version d’hivers 2021 du Logiciel";
                cout<< "\n-------------------------------------------";
                cout<< "\n Appuyez sur une touche deux fois pour finir";
                cout<< "\n-------------------------------------------";
            }

            etat = E0;
            choix = _getch();
            break;

        case E2: //Ao clicar na opçao 2, entra nas informaçoes abaixo:
        
                cout<< "\n-------------------------------------------";
                cout<< "\n            Mini Calculatrice";
                cout<< "\n-------------------------------------------";
                cout<< "\n     DÉFINIR LES PARAMÈTRES – OPTION (2)";
                cout<< "\n-------------------------------------------";
                cout<< "\n PROPRIETES: ";
                cout<< "\n Nom du Programmeur : Bianca Fernandes Nascimento";
                cout<< "\n Date de création : 30/10/2021";
                cout<< "\n Lieu de développement : Institut Grasset";
                cout<< "\n Option en cours : " << option;
                cout<< "\n-------------------------------------------";
                cout<< "\n CHOISISSEZ L’OPTION DU LOGICIEL";
                cout<< "\n 1 - Additionneuse à 1 seule opération ";
                cout<< "\n 2 - Table de Multiplication ";
                cout<< "\n 3 - Calculatrice Scientifique ";
                cout<< "\n CHOIX= ";
                cout<< "\n-------------------------------------------";

                // o usuario vai escolher a opçao

                choix2 = _getch();

                switch (choix2) {
                case '1':
                    option = 1; break;
                case '2':
                    option = 2; break;
                case '3':
                    option = 3; break;
                }
                
                etat = E0;
                break;
                

        case E3: //Ao clicar na opçao 3, entra nas informaçoes abaixo:
            cout<< "\n-------------------------------------------";
            cout<< "\n            Mini Calculatrice";
            cout<< "\n-------------------------------------------";
            cout<< "\n            AIDE - OPTION (3)";
            cout<< "\n-------------------------------------------";
            cout<< "\n Ce logiciel offre les fonctions de base d’une calculatrice (Addition, Soustraction, Multiplication et Division)";
            cout<< "\n-------------------------------------------";
            cout<< "\n       Sous Menu: ";
            cout<< "\n-------------------------------------------";
            cout<< "\n 1 - Le menu 1 permet de définir les paramètres du logiciel";
            cout<< "\n 2 - Le menu 2 vous propose l’aide que vous lisez actuellement";
            cout<< "\n 3 - Le menu 3 vous amène à la saisie de l’opération";
            cout<< "\n Q - La touche Q permet de quitter le programme";
            cout<< "\n-------------------------------------------";
            cout << "\n Appuyez sur une touche deux fois pour finir";

            choix = _getch();
            etat = E0;
            break;

        case E4:
            //Ao clicar na opçao 3 no sub-menu 3, entra nas informaçoes abaixo, que finaliza o programa:
            cout<< "\n-------------------------------------------";
            cout<< "\n             Mini Calculatrice";
            cout<< "\n-------------------------------------------";
            cout<< "\n     QUITTER LE LOGICIEL - OPTION (4)";
            cout<< "\n-------------------------------------------";
            cout<< "\n FIN DU PROGRAMME";
            cout<< "\n Merci d’avoir utilisé la MiniCalculatrice";
            cout<< "\n-------------------------------------------";
            cout<< "\n Appuyez sur une touche deux fois pour finir";
            cout<< "\n-------------------------------------------";

            choix = _getch();
            etat = E5;
            break;

        default: etat = E0;
        break;
        }

    }while (etat != E5);

    return 0;

}

void fonctionSomme()
{ 
    float n1, n2;

    cout<< "\n-------------------------------------------------------";
    cout<< "\n Veuillez écrire deux nombres entiers afin que nous puissions faire la somme pour vous :";
    cin >> n1 >> n2;
    float somme = n1 + n2; //operacao normal de soma entre 2 numeros digitados pelo usuario
    cout<< n1 << "+" << n2 << "=" << somme << endl;
    cout<< "\n-------------------------------------------------------";

    return; //Quando é void retorna assim porque é padrao
}

void fonctionSoustration()
{ 
    float n1, n2;
    cout<< "\n-------------------------------------------------------";
    cout<< "\n Veuillez écrire deux nombres entiers afin que nous puissions faire la soustration pour vous :";
    cin >> n1 >> n2;
    float soustration = n1 - n2; //operacao normal de subtraçao entre 2 numeros digitados pelo usuario
    cout<< n1 << "-" << n2 << "=" << soustration << endl;
    cout<< "\n-------------------------------------------------------";

    return;
}

void fonctionMultiplication()
{ 
    float n1, n2;
    cout<< "\n-------------------------------------------------------";
    cout<< "\n Veuillez écrire deux nombres entiers afin que nous puissions faire la multiplication pour vous :";
    cin >> n1 >> n2;
    float multiplication = n1 * n2; //operacao normal de multiplicaçao entre 2 numeros digitados pelo usuario
    cout<< n1 << "x" << n2 << "=" << multiplication << endl;
    cout<< "\n-------------------------------------------------------";

    return;
}

void fonctionDivision()
{
    float n1, n2;
    cout<< "\n-------------------------------------------------------";
    cout<< "\n Veuillez écrire deux nombres entiers afin que nous puissions faire la division pour vous :";
    cin >> n1 >> n2;
    float division = (float)n1 / n2; //operacao normal de divisao entre 2 numeros digitados pelo usuario
    cout<< n1 << "÷" << n2 << "=" << division << endl;
    cout<< "\n-------------------------------------------------------";

    return;
}
